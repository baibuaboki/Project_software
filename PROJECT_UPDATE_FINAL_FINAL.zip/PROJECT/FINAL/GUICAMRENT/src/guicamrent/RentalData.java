package guicamrent;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

public class RentalData {
    private static final String DATA_FILE = "src/Database/RentalData.csv";

    private RentalData() {
    }

    // อ่านทุกแถวจากไฟล์เช่าไว้ใน rows ภายในแต่ละ method

    public static boolean saveRentalDates(String username, String pickupDay, String pickupMonth,String returnDay, String returnMonth) { //เก็บวันเช่า User ไว้ก่อน
        try {
        
        ArrayList<String> rows = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {
            reader.readLine();
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    rows.add(line);
                }
            }
        }

        boolean dateRowFound = false;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DATA_FILE,false))) {

            writer.write("username,camera,pickupDay,pickupMonth,returnDay,returnMonth,status");
            writer.newLine();

            for (int i = 0; i < rows.size() ; i++) {
                String[] rental = rows.get(i).split(",",-1);
                if (rental[0].equals(username) && rental[1].isEmpty() && rental[6].isEmpty()) {
                    writer.write(username + ",," + pickupDay + "," + pickupMonth + "," + returnDay + "," + returnMonth + ",");
                    dateRowFound = true;
                }
                else{
                    writer.write(rows.get(i));
                }
                writer.newLine();
            } 

            // ถ้าผู้ใช้ยังไม่มีแถวว่าง ให้เพิ่มข้อมูลวันที่เป็นแถวใหม่
            if (!dateRowFound) {
                writer.write(username + ",," + pickupDay + "," + pickupMonth + "," + returnDay + "," + returnMonth + ",");
                writer.newLine();
            }
        }
        return true;
        } catch (Exception e) {
            e.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(null,
                    "บันทึกวันรับและวันคืนไม่สำเร็จ: " + e.getMessage()
                    + "\nตำแหน่งไฟล์: " + new File(DATA_FILE).getAbsolutePath(),
                    "เกิดข้อผิดพลาด", javax.swing.JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public static String[] getRentalDates(String username) {

        ArrayList<String> rows = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))){ 
            reader.readLine();
            
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    rows.add(line);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        for (int i = rows.size() - 1; i >= 0; i--) {
            String[] rental = rows.get(i).split(",", -1);

            // ใช้แถวล่าสุดของผู้ใช้ที่มีวันที่ครบ แม้ช่องกล้องหรือสถานะจะมีค่าอยู่แล้ว
            if (rental.length >= 6 && rental[0].trim().equals(username.trim())
                    && !rental[2].trim().isEmpty() && !rental[3].trim().isEmpty()
                    && !rental[4].trim().isEmpty() && !rental[5].trim().isEmpty()) {
                return new String[] {
                    rental[2].trim(), rental[3].trim(), rental[4].trim(), rental[5].trim()
                };
            }
        }
        return null;
    }

    //หาเฉพาะรายการที่ยัง Active หรือ Late เพื่อเช็คว่าผู้ใช้เช่าอยู่หรือไม่
    public static String[] getRentalDetails(String username) {
        try {

        ArrayList<String> rows = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {
            reader.readLine();
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    rows.add(line);
                }
            }
        }

        for (int i = rows.size() - 1; i >= 0; i--) { //วนเก็บค่า status ใน Data ที่มี
            String[] rental = rows.get(i).split(",", -1);

            if (rental[0].equals(username) && !rental[1].isEmpty() && (rental[6].equals("Active") || rental[6].equals("Late"))) { //เช็คว่ามีกล้องไหมและเป็นสถานะอะไร

                //แปลงค่าที่เขียนเก็บมาของ Date เป็น Integer
                int pickupDay = Integer.parseInt(rental[2]) ; int pickupMonth = Integer.parseInt(rental[3]);
                int returnDay = Integer.parseInt(rental[4]) ; int returnMonth = Integer.parseInt(rental[5]);

                
                LocalDate pickupDate = LocalDate.of(2026, pickupMonth, pickupDay); //วันเริ่มเช่า
                LocalDate returnDate = LocalDate.of(2026, returnMonth, returnDay); //วันที่คืน
                long rentalDays = ChronoUnit.DAYS.between(pickupDate, returnDate) + 1; //ใช้คลาสแปลงวันที่ของภาษามาหาระยะห่างเพื่อดูว่าเช่ากี่วัน
                int dailyPrice = getDailyPrice(rental[1]); //ดึงค่าราคาของกล้องมาใช้โดยดูจากชื่อกล้องที่ส่งไป
                long totalPrice = dailyPrice * rentalDays; //คำนวณหาราคาที่ต้องจ่ายทั้งหมด
                DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");//แปลงเป็นรูป dd/mm/yyyy แทนการใช้ Tostring

                return new String[] {
                    rental[1], pickupDate.format(dateFormat),returnDate.format(dateFormat),rentalDays + "DAY",String.valueOf(totalPrice)  //ส่งค่ากลับไปเป็นข้อความ //ส่งราคาคืนไปถ้าคำนวณหาออกมาได้แล้ว
                };
            }
        }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean saveRentedCamera(String username, String cameraName) {

        try {
        // ตรวจว่าผู้ใช้หรือกล้องมีรายการที่ยังไม่คืนหรือไม่ และหาแถวที่ยังไม่เลือกกล้อง
        ArrayList<String> rows = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {
            reader.readLine();
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    rows.add(line);
                }
            }
        }
        int emptyBookingRow = -1; //รอเก็บค่าแถวที่ข้อมูลตรงกัน

        for (int i = 0; i < rows.size(); i++) {
            String[] rental = rows.get(i).split(",", -1);
            if (rental[0].equals(username) && rental[1].isEmpty() && rental[6].isEmpty() && !rental[2].isEmpty()) { //ถ้า username ตรงกัน และ ไม่มีกล้อง Status แต่มี Date
                emptyBookingRow = i; //กำหนดแถวที่ผู้ใช้ยังไม่ได้เช่ากล้อง
            }
                if (rental[1].equals(cameraName) && (rental[6].equals("Active") || rental[6].equals("Late"))) { 
                    javax.swing.JOptionPane.showMessageDialog(null,"กล้องตัวนี้มีผู้เช่าอยู่แล้ว","เช่าไม่สำเร็จ",javax.swing.JOptionPane.WARNING_MESSAGE
    );
}
    return false;
        }
        //ใช้สำหรับตอนกดปุ่มยืนยันเช่า
        String[] rental = rows.get(emptyBookingRow).split(",", -1); // แบ่งข้อมูลด้วย , ในแถวนั้น
        rows.set(emptyBookingRow, username + "," + cameraName + "," + rental[2] + "," + rental[3] + "," + rental[4] + "," + rental[5] + ",Active"); //เขียนค่าใหม่และเพิ่มสถานะเข้าไป
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DATA_FILE, false))) {
            writer.write("username,camera,pickupDay,pickupMonth,returnDay,returnMonth,status");
            writer.newLine();
            for (String row : rows) {
                writer.write(row);
                writer.newLine();
            }
        }
        return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static String[] getAdminRental(String cameraName) { 
        try {
       
        //หาเจ้าของกล้องที่กำลังเช่า
        ArrayList<String> rows = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {
            reader.readLine();
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    rows.add(line);
                }
            }
        }
        String[] returnedRental = null;

        for (String row : rows) { //วนหาชื่อกล้องจนกว่าจะตรงกัน
            String[] rental = row.split(",", -1);
            if (rental[1].equals(cameraName)) {
                String dates = rental[2].isEmpty() ? "Dates unavailable" : rental[2] + "/" + rental[3] + "/2026 - " + rental[4] + "/" + rental[5] + "/2026"; //ดึงค่าวันที่มาเก็บ
                String phone = "-";
                
                File userFile = new File("src/Database/UserData.csv");
                if (userFile.exists()) {
                    try (BufferedReader userReader = new BufferedReader(new FileReader(userFile))) {
                        userReader.readLine(); // ข้ามหัวตาราง
                        String userLine;
                        while ((userLine = userReader.readLine()) != null) {
                            String[] user = userLine.split(",", -1);
                            if (user[0].equals(rental[0])) { //เช็คว่า user เดียวกันไหม
                                phone = user[1]; //กำหนดเบอร์คนเช่าไว้สำหรับใส่ให้ ADMIN
                                break;
                            }
                    }
                }
            }
            String[] renterInfo = { rental[0], phone, dates, rental[6] }; 
            
            if (rental[6].equals("Active") || rental[6].equals("Late")) { //ถ้าจองแล้วก็คืนค่า Active/Late
                return renterInfo;
            }
            if (rental[6].equals("Returned")) { //ถ้าคืนแล้วก็จะส่งค่าที่ตรวจนั้นกลับว่าตัวนี้คืนแล้ว
                returnedRental = renterInfo;
            }
        }
    }
        return returnedRental;
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}

public static boolean updateRentalStatus(String cameraName, String newStatus) { //รับกล้องกับ status เข้ามา
        try {
        //บันทึกรายการที่ ADMIN เปลี่ยนสถานะ โดยเก็บรายการ Returned ไว้เป็นประวัติ
        ArrayList<String> rows = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {
            reader.readLine();
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    rows.add(line);
                }
            }
        }
        int rentalRow = -1; // ยังไม่เริ่มเก็บแถว

        for (int i = 0; i < rows.size(); i++) {
            String[] rental = rows.get(i).split(",", -1); //แบ่งข้อมูลด้วย , ในแถวนั้นๆ
            String status = rental[6]; // กำหนดให้ status คือตัวที่ 7
            if (rental[1].equals(cameraName) && (status.equals("Active") || status.equals("Late"))) { //ถ้ามีชื่อตรงกับที่รับมาและมี status จะคืนตำแหน่งแถวที่เก็บข้อมูล
                rentalRow = i;
            }
        }

        String[] rental = rows.get(rentalRow).split(",", -1); //ดูค่าในตำแหน่งแถวที่ได้คืนมา
        rows.set(rentalRow, rental[0] + "," + rental[1] + "," + rental[2] + "," + rental[3] + "," + rental[4] + "," + rental[5] + "," + newStatus); //เปลี่ยนค่า status เป็นค่าใหม่ที่ ADMIN กำหนดมา
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DATA_FILE, false))) {
            writer.write("username,camera,pickupDay,pickupMonth,returnDay,returnMonth,status");
            writer.newLine();
            for (String row : rows) {
                writer.write(row);
                writer.newLine();
            }
        }
        return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static int[] getRentalStatusCounts() { 
        try {
        // นับสถานะล่าสุดของกล้องแต่ละตัว โดยอ่านจากแถวใหม่สุดก่อน
        ArrayList<String> rows = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {
            reader.readLine();
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    rows.add(line);
                }
            }
        }
        int activeCount = 0;
        int returnedCount = 0;
        int lateCount = 0;

        for (int i = rows.size() - 1; i >= 0; i--) { //วนหาค่า status ในไฟล์ทั้งหมดเพื่อนับ
            String[] rental = rows.get(i).split(",", -1);


            if (rental[6].equals("Active")) activeCount++;
            else if (rental[6].equals("Returned")) returnedCount++;
            else if (rental[6].equals("Late")) lateCount++;
        }

        return new int[] { activeCount, returnedCount, lateCount };
        } catch (Exception e) {
            e.printStackTrace();
            return new int[] { 0, 0, 0 };
        }
    }

    private static int getDailyPrice(String cameraName) { //ราคาเช่ากล้อง
        if (cameraName.equals("Sony A7V")) return 1400;
        if (cameraName.equals("Sony ZV-E10 + Lens")) return 500;
        if (cameraName.equals("Canon EOS R6 Mark II")) return 1300;
        if (cameraName.equals("Canon IXUS 285 HS A")) return 400;
        if (cameraName.equals("Fujifilm GFX 100S")) return 1900;
        if (cameraName.equals("Fujifilm X100 VI")) return 1000;
        if (cameraName.equals("Panasonic Lumix S9")) return 950;
        if (cameraName.equals("Panasonic Lumix DC-GH6")) return 900;
        return 0;
    }
}
