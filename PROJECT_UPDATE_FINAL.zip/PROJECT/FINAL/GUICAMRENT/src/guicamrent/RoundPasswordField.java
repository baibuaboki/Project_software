package guicamrent;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.BorderFactory;
import javax.swing.JPasswordField;

/** A rounded password field with optional hint text shown while it is empty. */
public class RoundPasswordField extends JPasswordField {
    private Color fillColor = new Color(236, 240, 241);
    private Color lineColor = Color.BLACK;
    private int strokeWidth = 1;
    private String placeholder = "";

    public RoundPasswordField() {
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(2, 10, 2, 10));
    }

    public void setPlaceholder(String placeholder) {
        if (this.placeholder == null) {
            this.placeholder = "";
        }else{
            this.placeholder = placeholder;
        }
    }
    @Override
    protected void paintComponent(Graphics g) {
        if (!isOpaque()) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth() - 2 * strokeWidth;
            int h = getHeight() - 2 * strokeWidth;
            g2d.setColor(fillColor);
            g2d.fillRoundRect(strokeWidth, strokeWidth, w, h, h, h);
            g2d.setStroke(new BasicStroke(strokeWidth));
            g2d.setColor(lineColor);
            g2d.drawRoundRect(strokeWidth, strokeWidth, w, h, h, h);
            g2d.dispose();
        }
        super.paintComponent(g);

        if (getPassword().length == 0 && !placeholder.isEmpty()) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setColor(new Color(130, 130, 130));
            FontMetrics metrics = g2d.getFontMetrics();
            int y = (getHeight() - metrics.getHeight()) / 2 + metrics.getAscent();
            g2d.drawString(placeholder, getInsets().left, y);
            g2d.dispose();
        }
    }
}
