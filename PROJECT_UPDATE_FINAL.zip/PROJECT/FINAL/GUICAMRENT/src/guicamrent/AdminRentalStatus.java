package guicamrent;

import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

public class AdminRentalStatus {

    public static void connect(String[] cameraNames, JLabel[][] renterLabels,JRadioButton[][] statusButtons, RoundButton activeCount,RoundButton returnedCount, RoundButton lateCount) {

        for (int row = 0; row < cameraNames.length; row++) {
            ButtonGroup statusGroup = new ButtonGroup();

            for (JRadioButton button : statusButtons[row]) {
                statusGroup.add(button);
            }

            final int cameraRow = row;
            for (JRadioButton button : statusButtons[row]) {
                button.addActionListener(event -> {
                    if (button.isSelected()) {
                        saveStatus(cameraNames[cameraRow], button.getText(),
                                renterLabels[cameraRow], statusButtons[cameraRow],
                                statusGroup, activeCount, returnedCount, lateCount);
                    }
                });
            }

            showRental(cameraNames[row], renterLabels[row],statusButtons[row], statusGroup);
        }

        updateSummary(activeCount, returnedCount, lateCount);
    }

    private static void showRental(String cameraName, JLabel[] labels,JRadioButton[] buttons, ButtonGroup statusGroup) {
        String[] renter = RentalData.getAdminRental(cameraName);

        if (renter == null) {
            statusGroup.clearSelection();
            for (JRadioButton button : buttons) {
                button.setEnabled(false);
            }
            return;
        }

        boolean wasReturned = renter[3].equals("Returned");
        labels[0].setText((wasReturned ? "Returned by: " : "Username: ") + renter[0]);
        labels[1].setText("Phone: " + renter[1]);
        labels[2].setText("Dates: " + renter[2]);

        for (JRadioButton button : buttons) {
            button.setEnabled(!wasReturned);
            button.setSelected(button.getText().equals(renter[3]));
        }

        if (renter[3].isEmpty() && buttons.length > 0) {
            buttons[0].setSelected(true);
        }
    }

    private static void saveStatus(String cameraName, String status,JLabel[] labels, JRadioButton[] buttons, ButtonGroup statusGroup,RoundButton activeCount, RoundButton returnedCount, RoundButton lateCount) {
        if (RentalData.updateRentalStatus(cameraName, status)) {
            showRental(cameraName, labels, buttons, statusGroup);
            updateSummary(activeCount, returnedCount, lateCount);
        }
    }

    private static void updateSummary(RoundButton activeCount,RoundButton returnedCount, RoundButton lateCount) {
        int[] counts = RentalData.getRentalStatusCounts();
        activeCount.setText("Active : " + counts[0]);
        returnedCount.setText("Returned : " + counts[1]);
        lateCount.setText("Late : " + counts[2]);
    }
}
