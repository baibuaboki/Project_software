package guicamrent;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class UserData {
    private static final String DATA_FILE = "src/Database/UserData.csv"; //ตำแหน่งเขียนทับไฟล์
    private static String currentUsername = ""; //เก็บข้อมูล username ปัจจุบันที่ใช้งานอยู่

    private final String username;
    private final String phone;
    private final String email;
    private final String password;

    public UserData(String username, String phone, String email, String password) { //กำหนดค่าเริ่มต้นของโปรแกรมเป็นค่าที่รับเข้ามา
        this.username = username;
        this.phone = phone;
        this.email = email;
        this.password = password;
    }

    public String getUsername() { 
        return username; 
    }

    public String getEmail() { 
        return email; 
    }

    public String getPassword() { 
        return password; 
    }

    public static void setCurrentUsername(String username) { //เซ็ท username ปัจจุบันที่ใช้งานอยู่ด้วย username ที่รับเข้ามา
        currentUsername = username;
    } 

    public static String getCurrentUsername() {
        return currentUsername;
    }

    public static boolean usernameExists(String username) throws IOException {  //ส่ง username ไปเช็ค
        return valueExists(username, 0); 
    }

    public static boolean emailExists(String email) throws IOException { //ส่ง email ไปเช็ค
        return valueExists(email, 2);
    }

    public static boolean checkLogin(String username, String password){ //รับ username password ที่ใส่มาเช็คว่ามีอยู่ใน Database แล้วยัง
        
        try {BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE));
            reader.readLine(); // ข้ามหัวตาราง

            String line;
            while ((line = reader.readLine()) != null) { //อ่านทุกบรรทัดจนกว่าจะไม่มีข้อมูล
                String[] user = line.split(","); //เก็บข้อมูล user ไว้ใน array เพื่อเอาไว้ตรวจเช็คง่ายๆ
                if (user[0].equals(username) && user[3].equals(password)) { //เช็คว่า username กับ password มีใน Database ไหม
                    reader.close();
                    return true;
                    
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void save() throws IOException { //เขียนข้อมูลบันทึกลงใน Database
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DATA_FILE, true))) { //เขียนข้อมูลไปเรื่อยๆโดยไม่ลบข้อมูลคนเก่าทิ้้งออก
            writer.write(username + "," + phone + "," + email + "," + password); //เขียนข้อมูลเก็บเข้า Database
            writer.newLine();
            }
        }

    private static boolean valueExists(String value, int column) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {reader.readLine(); // ข้ามหัวตารางแถวแรกก่อน
            String line;
            while ((line = reader.readLine()) != null) { //อ่าน Database ทีละบรรทัดจนกว่าจะ null
                if (line.isBlank()) {
                    continue;
                }

                String[] fields = line.split(",", -1); //เก็บข้อมูลเป็นช่องแบ่งด้วย , 
                if (fields[column].equals(value)) { //เช็คว่าข้อมูลมีใน Database ที่ซ้ำกันไหมไหม
                    return true;
                }
            }
        }
        return false;
    }
}
