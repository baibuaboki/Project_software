package guicamrent;

import java.io.IOException;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

/**เชื่อมปุ่มสถานะของกล้องแต่ละตัวกับรายการเช่า*/
public final class AdminRentalStatus {
    private AdminRentalStatus() {
    }

    public static void connect(String[] cameraNames, JLabel[][] renterLabels,JRadioButton[][] statusButtons, guicamrent.RoundButton activeCount,guicamrent.RoundButton returnedCount, guicamrent.RoundButton lateCount) {
        for (int row = 0; row < cameraNames.length; row++) {
            //ButtonGroup บังคับให้กล้องหนึ่งตัวเลือกสถานะได้ครั้งละหนึ่งปุ่ม
            ButtonGroup statusGroup = new ButtonGroup();

            for (JRadioButton button : statusButtons[row]) {
                statusGroup.add(button);
            }

            final int rowNumber = row;
            for (JRadioButton button : statusButtons[row]) {
                button.addActionListener(event -> {if (button.isSelected()) {saveStatus(cameraNames[rowNumber], button.getText(), renterLabels[rowNumber],statusButtons[rowNumber], statusGroup,activeCount, returnedCount, lateCount);
                    }
                });
            }
            showRental(cameraNames[row], renterLabels[row], statusButtons[row], statusGroup);
        }

        updateSummary(activeCount, returnedCount, lateCount);
    }

    private static void showRental(String cameraName, JLabel[] labels,JRadioButton[] buttons, ButtonGroup statusGroup) {
        try {
            String[] renter = RentalData.getAdminRental(cameraName);

            if (renter == null) {
                statusGroup.clearSelection();
                for (JRadioButton button : buttons) {
                    button.setEnabled(false);
                }
                return;
            }

            boolean wasReturned = "Returned".equals(renter[3]);
            labels[0].setText((wasReturned ? "Returned by: " : "Username: ") + renter[0]);
            labels[1].setText("Phone: " + renter[1]);
            labels[2].setText("Dates: " + renter[2]);
            for (JRadioButton button : buttons) {
                button.setEnabled(!wasReturned);
                button.setSelected(button.getText().equals(renter[3]));
            }

            // ถ้าเป็นข้อมูลเช่าเดิมที่ยังไม่มีสถานะ ให้เริ่มที่ Active
            if (!"Late".equals(renter[3]) && !wasReturned) {
                buttons[0].setSelected(true);
            }
        } catch (IOException ex) {
            labels[0].setText("Could not read renter");
            labels[1].setText("Phone: -");
            labels[2].setText("Dates: -");
            for (JRadioButton button : buttons) {
                button.setEnabled(false);
            }
        }
    }

    private static void saveStatus(String cameraName, String status, JLabel[] labels,JRadioButton[] buttons, ButtonGroup statusGroup,guicamrent.RoundButton activeCount, guicamrent.RoundButton returnedCount,guicamrent.RoundButton lateCount) {
        try {
            //บันทึกสถานะที่ ADMIN เลือก แล้วอ่านข้อมูลมาอัปเดตหน้าจอและยอดรวม
            RentalData.updateRentalStatus(cameraName, status);showRental(cameraName, labels, buttons, statusGroup);
            updateSummary(activeCount, returnedCount, lateCount);
        } catch (IOException ex) {
        }
    }

    private static void updateSummary(guicamrent.RoundButton activeCount,
            guicamrent.RoundButton returnedCount, guicamrent.RoundButton lateCount) {
        try {
            int[] counts = RentalData.getRentalStatusCounts();
            activeCount.setText("Active : " + counts[0]);
            returnedCount.setText("Returned : " + counts[1]);
            lateCount.setText("Late : " + counts[2]);
        } catch (IOException ex) {
        }
    }
}
