package guicamrent;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

public class RentalData {
    private static final String DATA_FILE = "src/Database/RentalData.csv";

    private RentalData() {
    }

    //อ่านทุกแถวจากไฟล์เช่า
    private static ArrayList<String> readRentalRows() throws IOException {
        ArrayList<String> rows = new ArrayList<>(); //กำหนด Arrylist มาเก็บข้อมูลแถวทั้งหมดว่ามีกี่แถว

        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {reader.readLine(); //ข้ามหัวแถวไปก่อน
            String line;
            while ((line = reader.readLine()) != null) { //อ่านไฟล์ทั้งหมดใน Database
                if (!line.isBlank()) {
                    rows.add(line);
                }
            }
        }
        return rows; //ส่ง rows กลับไปว่ามีกี่แถว
    }

    //รับข้อมูลทั้งหมดมาเพื่อเขียนลงในไฟล์
    private static void writeRentalRows(ArrayList<String> rows) throws IOException { //เขียนข้อมูลกลับลง Database
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DATA_FILE, false))) { //เขียนใหม่โดยไม่ต่อจากไฟล์เดิมลบของเก่าทิ้งเพราะต้องแก้ค่า ADMIN

            writer.write("username,camera,pickupDay,pickupMonth,returnDay,returnMonth,status"); //เขียนหัวตารางระบุใหม่ก่อนทุกครั้งเพราะลบจากครั้งก่อนหน้า
            writer.newLine();

            for (String row : rows) { //เขียนทุกบรรทัดทั้งหมดใหม่
                writer.write(row);
                writer.newLine();
            }
        }
    }

    public static void saveRentalDates(String username, String pickupDay, String pickupMonth,String returnDay, String returnMonth) throws IOException { //เก็บวันเช่า User ไว้ก่อน
        
        // บันทึกวันที่โดยเว้นช่องกล้องและสถานะไว้ก่อน
        ArrayList<String> rows = readRentalRows(); //อ่านข้อมูลเดิมทั้งหมดที่มีอยู่แล้วใน RentalData แล้วเก็บไว้ใน rows เพื่อไม่หายข้อมูลคนอื่นหายและดูว่า user ติดสถานะจองอยู่ไหม
        int emptyBookingRow = -1; //เก็บตำแหน่งแถวให้เริ่มต้นเป็น -1 เพราะโปรแกรมจะเริ่มนับที่ 0 

        for (int i = 0; i < rows.size(); i++) { //วนหาแถวใน RentalData ทั้งหมดว่ามีกี่แถว
            String[] rental = rows.get(i).split(",", -1); //เก็บข้อความของแต่ละแถวด้วย array โดยแบ่งข้อมูลเป็นบล็อกจาก ,
            if (rental[0].equals(username) && rental[1].isEmpty() && rental[6].isEmpty()) { //ช่อง username ตรงกับค่าที่รับเข้ามา และ ยังไม่มีกล้องที่เช่าอยู่ และ ไม่มีสถานะอะไรอยู่
                emptyBookingRow = i; // บันทึกข้อมูลว่า username นี้เก็บข้อมูลอยู่แถวที่เท่าไหร่
            }
        }

        String newRow = username + ",," + pickupDay + "," + pickupMonth + ","+ returnDay + "," + returnMonth + ","; //เก็บช้อมูลที่เราเข้ามาเอาไว้ newRow

        if (emptyBookingRow == -1) { //ถ้ายังเป็น -1 อยู่แปลว่าในนี้ไม่มีข้อมูลที่ตรงกันเลย
            rows.add(newRow); //เพิ่มแถวใหม่ด้วยข้อมูลที่รับเข้ามา
        } else {
            rows.set(emptyBookingRow, newRow); //ถ้าไม่เป็น -1 ก็จะเขียนทับข้อมูลแถวนั้นเลย
        }
        writeRentalRows(rows); //ส่งค่าข้อมูลที่อัพเดทใหม่ไปเขียนลงในไฟล์ RentalData
    }

    public static String[] getRentalDates(String username) throws IOException {
        ArrayList<String> rows = readRentalRows();

        // อ่านจากล่างขึ้นบนเพื่อให้ได้วันที่ที่ผู้ใช้เลือกครั้งล่าสุด
        for (int i = rows.size() - 1; i >= 0; i--) {
            String[] rental = rows.get(i).split(",", -1);
            if (rental[0].equals(username) && rental[1].isEmpty() && rental[6].isEmpty() && !rental[2].isEmpty()) {
                return new String[] { rental[2], rental[3], rental[4], rental[5] };
            }
        }
        return null;
    }

    //หาเฉพาะรายการที่ยัง Active หรือ Late เพื่อเช็คว่าผู้ใช้เช่าอยู่หรือไม่
    public static String[] getRentalDetails(String username) throws IOException {

        ArrayList<String> rows = readRentalRows(); //ดึง Database ทั้งหมดมาเก็บไว้ใน rows

        for (int i = rows.size() - 1; i >= 0; i--) { //วนเก็บค่า status ใน Data ที่มี
            String[] rental = rows.get(i).split(",", -1);
            String status = rental[6]; 

            if (rental[0].equals(username) && !rental[1].isEmpty() && (status.equals("Active") || status.equals("Late"))) { //เช็คว่ามีกล้องไหมและเป็นสถานะอะไร

                //แปลงค่าที่เขียนเก็บมาของ Date เป็น Integer
                int pickupDay = Integer.parseInt(rental[2]); 
                int pickupMonth = Integer.parseInt(rental[3]);
                int returnDay = Integer.parseInt(rental[4]);
                int returnMonth = Integer.parseInt(rental[5]);

                
                LocalDate pickupDate = LocalDate.of(2026, pickupMonth, pickupDay); //วันเริ่มเช่า
                LocalDate returnDate = LocalDate.of(2026, returnMonth, returnDay); //วันที่คืน
                long rentalDays = ChronoUnit.DAYS.between(pickupDate, returnDate) + 1; //ใช้คลาสแปลงวันที่ของภาษามาหาระยะห่างเพื่อดูว่าเช่ากี่วัน
                int dailyPrice = getDailyPrice(rental[1]); //ดึงค่าราคาของกล้องมาใช้โดยดูจากชื่อกล้องที่ส่งไป
                long totalPrice = dailyPrice * rentalDays; //คำนวณหาราคาที่ต้องจ่ายทั้งหมด
                DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");//แปลงเป็นรูป dd/mm/yyyy แทนการใช้ Tostring

                return new String[] {
                    rental[1], pickupDate.format(dateFormat),returnDate.format(dateFormat),rentalDays + (rentalDays == 1 ? " day" : " days"), //ส่งค่ากลับไปเป็นข้อความ
                    dailyPrice == 0 ? "Price unavailable" : String.format("%,d THB", totalPrice) //ส่งราคาคืนไปถ้าคำนวณหาออกมาได้แล้ว
                };
            }
        }
        return null;
    }

    public static void saveRentedCamera(String username, String cameraName) throws IOException {
        // ตรวจว่าผู้ใช้หรือกล้องมีรายการที่ยังไม่คืนหรือไม่ และหาแถวที่ยังไม่เลือกกล้อง
        ArrayList<String> rows = readRentalRows(); //อ่านค่าทั้งหมดมาและเก็บจำนวนแถว
        int emptyBookingRow = -1; //รอเก็บค่าแถวที่ข้อมูลตรงกัน

        for (int i = 0; i < rows.size(); i++) {
            String[] rental = rows.get(i).split(",", -1);
            String status = rental[6]; //เก็บข้อมูลของ Status

            if (rental[0].equals(username) && (status.equals("Active") || status.equals("Late"))) { //ถ้า username ตรงกัน และมีสถานะ
                throw new IOException("ผู้ใช้นี้มีรายการเช่าที่ยังไม่คืน");
            }

            if (rental[1].equals(cameraName) && (status.equals("Active") || status.equals("Late"))) { // ถ้ากล้องตรงกันและมี status 
                throw new IOException("กล้องตัวนี้มีผู้เช่าอยู่แล้ว");
            }

            if (rental[0].equals(username) && rental[1].isEmpty() && status.isEmpty() && !rental[2].isEmpty()) { //ถ้า username ตรงกัน และ ไม่มีกล้อง Status แต่มี Date
                emptyBookingRow = i; //กำหนดแถวที่ผู้ใช้ยังไม่ได้เช่ากล้อง
            }
        }

        if (emptyBookingRow == -1) {
            throw new IOException();
        }

        //ใช้สำหรับตอนกดปุ่มยืนยันเช่า
        String[] rental = rows.get(emptyBookingRow).split(",", -1); // แบ่งข้อมูลด้วย , ในแถวนั้น
        rows.set(emptyBookingRow, username + "," + cameraName + "," + rental[2] + "," + rental[3] + "," + rental[4] + "," + rental[5] + ",Active"); //เขียนค่าใหม่และเพิ่มสถานะเข้าไป
        writeRentalRows(rows); //เพิ่มค่าใหม่ลงใน Database
    }

    public static String[] getAdminRental(String cameraName) throws IOException { 
       
        //หาเจ้าของกล้องที่กำลังเช่า
        ArrayList<String> rows = readRentalRows();
        String[] returnedRental = null;

        for (String row : rows) { //วนหาชื่อกล้องจนกว่าจะตรงกัน
            String[] rental = row.split(",", -1);
            if (!rental[1].equals(cameraName)) {
                continue; //ข้ามไปดูแถวต่อไป
            }

            String status = rental[6];
            String dates = rental[2].isEmpty() ? "Dates unavailable" : rental[2] + "/" + rental[3] + "/2026 - " + rental[4] + "/" + rental[5] + "/2026"; //ดึงค่าวันที่มาเก็บ
            String phone = "-";
            File userFile = new File("src/Database/UserData.csv");
            if (userFile.exists()) {
                try (BufferedReader userReader = new BufferedReader(new FileReader(userFile))) {
                    userReader.readLine(); // ข้ามหัวตาราง
                    String userLine;
                    while ((userLine = userReader.readLine()) != null) {
                        String[] user = userLine.split(",", -1);
                        if (user.length >= 2 && user[0].equals(rental[0])) { //เช็คว่า user เดียวกันไหม
                            phone = user[1]; //กำหนดเบอร์คนเช่าไว้สำหรับใส่ให้ ADMIN
                            break;
                        }
                    }
                }
            }
            String[] renterInfo = { rental[0], phone, dates, status }; 

            if (status.equals("Active") || status.equals("Late")) { //ถ้าจองแล้วก็คืนค่า Active/Late
                return renterInfo;
            }
            if (status.equals("Returned")) { //ถ้าคืนแล้วก็จะส่งค่าที่ตรวจนั้นกลับว่าตัวนี้คืนแล้ว
                returnedRental = renterInfo;
            }
        }
        return returnedRental;
    }

    public static void updateRentalStatus(String cameraName, String newStatus) throws IOException { //รับกล้องกับ status เข้ามา
        //บันทึกรายการที่ ADMIN เปลี่ยนสถานะ โดยเก็บรายการ Returned ไว้เป็นประวัติ
        ArrayList<String> rows = readRentalRows(); //อ่านค่าทั้งหมดในไฟล์รอไว้สำหรับเอาไปเทียบต่อ
        int rentalRow = -1; // ยังไม่เริ่มเก็บแถว

        for (int i = 0; i < rows.size(); i++) {
            String[] rental = rows.get(i).split(",", -1); //แบ่งข้อมูลด้วย , ในแถวนั้นๆ
            String status = rental[6]; // กำหนดให้ status คือตัวที่ 7
            if (rental[1].equals(cameraName) && (status.equals("Active") || status.equals("Late"))) { //ถ้ามีชื่อตรงกับที่รับมาและมี status จะคืนตำแหน่งแถวที่เก็บข้อมูล
                rentalRow = i;
            }
        }

        if (rentalRow == -1) {
            throw new IOException();
        }

        String[] rental = rows.get(rentalRow).split(",", -1); //ดูค่าในตำแหน่งแถวที่ได้คืนมา
        rows.set(rentalRow, rental[0] + "," + rental[1] + "," + rental[2] + "," + rental[3] + "," + rental[4] + "," + rental[5] + "," + newStatus); //เปลี่ยนค่า status เป็นค่าใหม่ที่ ADMIN กำหนดมา
        writeRentalRows(rows); //เขียนไฟล์ใหม่ใน RentalData
    }

    public static int[] getRentalStatusCounts() throws IOException { 
        // นับสถานะล่าสุดของกล้องแต่ละตัว โดยอ่านจากแถวใหม่สุดก่อน
        ArrayList<String> rows = readRentalRows();
        int activeCount = 0;
        int returnedCount = 0;
        int lateCount = 0;

        for (int i = rows.size() - 1; i >= 0; i--) { //วนหาค่า status ในไฟล์ทั้งหมดเพื่อนับ
            String[] rental = rows.get(i).split(",", -1);
            String status = rental[6];


            if (status.equals("Active")) activeCount++;
            else if (status.equals("Returned")) returnedCount++;
            else if (status.equals("Late")) lateCount++;
        }

        return new int[] { activeCount, returnedCount, lateCount };
    }

    private static int getDailyPrice(String cameraName) { //ราคาเช่ากล้อง
        if (cameraName.equals("Sony A7V")) return 1400;
        if (cameraName.equals("Sony ZV-E10 + Lens")) return 500;
        if (cameraName.equals("Canon EOS R6 Mark II")) return 1300;
        if (cameraName.equals("Canon IXUS 285 HS A")) return 400;
        if (cameraName.equals("Fujifilm GFX 100S")) return 1900;
        if (cameraName.equals("Fujifilm X100 VI")) return 1000;
        if (cameraName.equals("Panasonic Lumix S9")) return 950;
        if (cameraName.equals("Panasonic Lumix DC-GH6")) return 900;
        return 0;
    }
}
